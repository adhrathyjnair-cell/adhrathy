export type Tab = 'dashboard' | 'tasks' | 'calendar' | 'progress';

export type TaskCategory = 'Assignments' | 'Study' | 'Personal';

export type TaskPriority = 'High' | 'Medium' | 'Low';

export interface Task {
  id: string;
  title: string;
  category: TaskCategory;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // e.g. "11:59 PM"
  priority: TaskPriority;
  completed: boolean;
  completedDate?: string; // e.g. "Jun 10" or "Oct 23"
  estimatedMin?: number; // Estimated minutes, e.g., 45
}

export type EventType = 'Study' | 'Project' | 'Deadline';

export interface CalendarEvent {
  id: string;
  title: string;
  type: EventType;
  date: string; // YYYY-MM-DD
  startTime: string; // e.g. "09:00 AM"
  endTime?: string; // e.g. "11:30 AM"
  description?: string;
  location?: string; // e.g. "Lecture Hall B, Room 204"
  progress?: number; // percent value e.g. 75
}

export interface Milestone {
  id: string;
  title: string;
  icon: string;
  unlocked: boolean;
  description: string;
}

export interface StudySessionLog {
  id: string;
  date: string; // YYYY-MM-DD
  durationMinutes: number;
}
