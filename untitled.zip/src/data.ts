import { Task, CalendarEvent, Milestone } from './types';

export const PROFILE_AVATARS = [
  'https://lh3.googleusercontent.com/aida-public/AB6AXuBT_8f30SGs7HtuJJqs73t4nTR-HSsb1xmAWoZ5zYkE_NWodrp4KcMmovDKPJARFosX6vwSHWbGpoNiDZttfVwZNO23aTNL2oUIG1n2eANqJGdIBjiQAll8_w5zDGVr7cuF-Hjc2EWgZvoYgSbeUUDYGNk-E0UkhqtBbJxzWpKP8r5jpbTDBCPsgkoAb33CkN-SJek_SpOrf9HD-uzg1HId44pgNzlBrsC6PjwIo0mJccSYeFLFx3Ch02PCxqEnPESkTe4jDdjdTWo',
  'https://lh3.googleusercontent.com/aida-public/AB6AXuCUq7B8TXtbr7VUdi7oMBc00crDxAANNDFVLjRhTq5TR1c1Ra1A0ZdsfYQBtQvqiAgC8GvWzgIFPGjJtSWvyh4DiYOV-agYHn37Xnv9wuR-wQt-nZeNqkxbsIlGdL4TmQD1YM1REKGR0oVVpHnO0aE_XlWZFdkMs3Qf-knBMYUXeReRfw0Fggh0Gx-JAecDZS4JWGrmzs7u45AqhuNhiE5locK_KuJBce__kkR3rzSp32Sk1mcsWqp-eV4MMKdOJCPO_-Ac-Xtzy3o',
  'https://lh3.googleusercontent.com/aida-public/AB6AXuDQ51rcCILQLPo1NrzC6tp3BTrXeuwqGCiRxLumW9pd8ksRWEJuENi3CjIwWGP1GBy9k-ZKw0DdOuDHJhfXuSkquHajabTYUrMcUUvZwgdjf6hL3YZj_EKpafcp7frh3f_L6LdTqullxK1fjjmRggGkdFnVlKG6S9n4Jb38FYQ55l3Id_eULpibOqzhMDswICAriQYhiEDgAis3ZgJwD5G5_Ti2eVhkjWOlzZBzSLLeK79yLScu0nYys7wZaiFxFfcQ2VFo_fnTosk',
  'https://lh3.googleusercontent.com/aida-public/AB6AXuALZMOLwf1ugyW_0yIGt_z8lYU6YxFUqRc_oC6Y0CaJkVeSTCon91wpk8TYQl5u3HSY8G-N4kypYJOSl6wHVgoI04SVrHabgnWUCT015XC6MbnSwyhmf2nZH0yMZSbonOM6OHIvBDwHxdAxs99sH9H2Wf5Z2Dvf2IH2_mKjoTRffz8DLklq4lm8La5Xm5NuIHZn9cyahx05MAVMrc4q9eOJpIufzC-kbnOb5tk0ZLvasaGvEzoNixM5OsXg2lP9xDpAxpR_v3hgdiE'
];

export const INITIAL_TASKS: Task[] = [
  // Dashboard & Task Tab Incompletes
  {
    id: 't1',
    title: 'Research Methodology Chapter 3',
    category: 'Study',
    dueDate: '2026-06-10', // fits Sep 12 / current date
    dueTime: 'Due today',
    priority: 'High',
    completed: false,
  },
  {
    id: 't2',
    title: 'Review Statistics Notes',
    category: 'Study',
    dueDate: '2026-06-10',
    priority: 'Medium',
    completed: false,
    estimatedMin: 45
  },
  {
    id: 't3',
    title: 'Submit Philosophy Essay',
    category: 'Assignments',
    dueDate: '2026-06-10',
    dueTime: '11:59 PM',
    priority: 'High',
    completed: false
  },
  {
    id: 't4',
    title: 'Math Quiz Prep',
    category: 'Study',
    dueDate: '2026-06-10',
    dueTime: '4:00 PM',
    priority: 'Medium',
    completed: false
  },
  {
    id: 't5',
    title: 'Buy new lab coat',
    category: 'Personal',
    dueDate: '2026-06-10',
    dueTime: 'Today',
    priority: 'Low',
    completed: false
  },
  // Upcoming Tasks
  {
    id: 't6',
    title: 'Library Group Study',
    category: 'Study',
    dueDate: '2026-06-11',
    dueTime: 'Tomorrow, 2:00 PM',
    priority: 'Medium',
    completed: false
  },
  {
    id: 't7',
    title: 'Final Project Draft',
    category: 'Assignments',
    dueDate: '2026-06-13',
    dueTime: 'Friday, Oct 27',
    priority: 'High',
    completed: false
  },
  // Completed Tasks count to build 6 of 8 tasks completed
  {
    id: 't-comp1',
    title: 'Biology Lab Report',
    category: 'Assignments',
    dueDate: '2026-06-09',
    completed: true,
    completedDate: 'Jun 09'
  },
  {
    id: 't-comp2',
    title: 'Macroeconomics Homework 1',
    category: 'Assignments',
    dueDate: '2026-06-10',
    completed: true,
    completedDate: 'Jun 10'
  },
  {
    id: 't-comp3',
    title: 'Chemistry Pre-Lab Quiz',
    category: 'Study',
    dueDate: '2026-06-10',
    completed: true,
    completedDate: 'Jun 10'
  },
  {
    id: 't-comp4',
    title: 'Organize Study Materials',
    category: 'Personal',
    dueDate: '2026-06-10',
    completed: true,
    completedDate: 'Jun 10'
  },
  {
    id: 't-comp5',
    title: 'Email Professor about Essay',
    category: 'Assignments',
    dueDate: '2026-06-10',
    completed: true,
    completedDate: 'Jun 10'
  },
  {
    id: 't-comp6',
    title: 'Weekly Budget Review',
    category: 'Personal',
    dueDate: '2026-06-10',
    completed: true,
    completedDate: 'Jun 10'
  }
];

export const INITIAL_EVENTS: CalendarEvent[] = [
  {
    id: 'e1',
    title: 'Data Structures Review',
    type: 'Study',
    date: '2026-09-12', // Matches screen exact date
    startTime: '09:00 AM',
    endTime: '11:30 AM',
    description: 'Focus on binary trees and graph traversal algorithms for the upcoming midterm.',
    location: 'Main Library, Room 402'
  },
  {
    id: 'e2',
    title: 'Macroeconomics Essay',
    type: 'Project',
    date: '2026-09-12',
    startTime: '02:00 PM',
    endTime: '04:00 PM',
    progress: 75,
    description: 'Structure introduction and outline key empirical model statistics.',
    location: 'Lecture Hall B, Room 204'
  },
  {
    id: 'e3',
    title: 'UI Design Prototype',
    type: 'Deadline',
    date: '2026-09-12',
    startTime: '11:59 PM',
    description: 'Final submission of the high fidelity responsive application mockup.'
  },
  {
    id: 'e4',
    title: 'Chemistry Lab Session',
    type: 'Study',
    date: '2026-09-13',
    startTime: '10:00 AM',
    endTime: '12:00 PM',
    description: 'Experiment on calorimetry and thermal state equilibrium.',
    location: 'Science Center 302'
  }
];

export const INITIAL_MILESTONES: Milestone[] = [
  {
    id: 'm1',
    title: '7 Day Streak',
    icon: 'local_fire_department',
    unlocked: true,
    description: 'Studied for 7 consecutive days'
  },
  {
    id: 'm2',
    title: 'Deep Focus',
    icon: 'timer',
    unlocked: true,
    description: 'Completed 5 Pomodoro sessions'
  },
  {
    id: 'm3',
    title: 'Top Learner',
    icon: 'military_tech',
    unlocked: true,
    description: 'Finished 20 tasks in a week'
  },
  {
    id: 'm4',
    title: '100 Tasks',
    icon: 'lock',
    unlocked: false,
    description: 'Achieve 100 overall finished tasks'
  }
];

export const ZEN_AESTHETIC_QUOTES = [
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
  { text: "Flow with whatever may happen, and let your mind be free.", author: "Zhuangzi" },
  { text: "Focus is a matter of deciding what things you're not going to do.", author: "John Carmack" },
  { text: "Do not dwell in the past, do not dream of the future, concentrate the mind on the present.", author: "Buddha" },
];
